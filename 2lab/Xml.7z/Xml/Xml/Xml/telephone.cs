﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlTest
{
    class Student
    {
        public int Id { get; set; }
        public string mark { get; set; }
        public string model { get; set; }
        public int Age { get; set; }

        public static IEnumerable<Student> GetAllStudents()
        {
            return new List<Student>
                {
                    new Student{Id = 100, mark = "iphone", model = "5s", Age = 1},
                    new Student{Id = 101, mark = "samsung", model = "a8", Age = 2},
                    new Student{Id = 102, mark = "FLY", model = "1120", Age = 5},
                    new Student{Id = 103, mark = "Ipad", model = "Air", Age = 4},
                    new Student{Id = 104, mark = "Samsung", model = "S8", Age = 1}
            };
        }
    }
}
